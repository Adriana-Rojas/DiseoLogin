# Elcciones
Ejercicio de Linea 3 en el cual se registran candidatos y se simulan elecciones
